def classFactory(iface):
    from .PermitFiberAssociator import PermitFiberAssociator
    return PermitFiberAssociator(iface)