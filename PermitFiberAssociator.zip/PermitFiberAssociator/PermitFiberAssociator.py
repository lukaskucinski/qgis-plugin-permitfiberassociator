## PermitFiberAssociator.py

from PyQt5.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.core import *
from qgis.utils import iface
from .PermitFiberAssociator_dialog import PermitFiberAssociatorDialog
import os

class PermitFiberAssociator:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.dlg = PermitFiberAssociatorDialog()

    def initGui(self):
        icon = QIcon(os.path.join(self.plugin_dir, 'icon.png'))
        self.action = QAction(icon, 'Associate Permits with Fiber Segments', self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu('PermitFiberAssociator', self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu('PermitFiberAssociator', self.action)

    def run(self):
        self.dlg.show()
        self.dlg.exec_()