from PyQt5.QtWidgets import QDialog, QMessageBox
from .PermitFiberAssociator_dialog_base import Ui_PermitFiberAssociatorDialog
from qgis.core import QgsProject, QgsVectorLayer, QgsWkbTypes
from .config import DB_CONFIG
import psycopg2

class PermitFiberAssociatorDialog(QDialog, Ui_PermitFiberAssociatorDialog):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.populate_layer_comboboxes()
        self.pushButton.clicked.connect(self.associate_segments)

        # Re-populate layers anytime the dialog is re-opened
        self.finished.connect(self.populate_layer_comboboxes)
        
        # Re-populate layers when new layers are added or project is loaded
        QgsProject.instance().layersAdded.connect(self.populate_layer_comboboxes)
        QgsProject.instance().readProject.connect(self.populate_layer_comboboxes)

    def populate_layer_comboboxes(self):
        self.comboPermitLayer.clear()
        self.comboFiberLayer.clear()

        # Fetch all layers in the project
        layers = QgsProject.instance().mapLayers().values()

        for layer in layers:
            if not isinstance(layer, QgsVectorLayer):
                continue

            layer_name = layer.name()
            geometry_type = QgsWkbTypes.geometryType(layer.wkbType())

            # Only allow 'permits' if it is a Point layer
            if layer_name == 'permits' and geometry_type == QgsWkbTypes.PointGeometry:
                self.comboPermitLayer.addItem(layer_name)

            # Only allow 'fiber_construction_ositdb' if it is a Line layer
            elif layer_name == 'fiber_construction_ositdb' and geometry_type == QgsWkbTypes.LineGeometry:
                self.comboFiberLayer.addItem(layer_name)

    def get_layer_by_name(self, name):
        for layer in QgsProject.instance().mapLayers().values():
            if layer.name() == name:
                return layer
        return None

    def associate_segments(self):
        permit_layer = self.get_layer_by_name("permits")
        fiber_layer = self.get_layer_by_name("fiber_construction_ositdb")

        if not permit_layer or not fiber_layer:
            QMessageBox.warning(self, 'Error', 'Expected layers not found (permits, fiber_construction_ositdb).')
            return

        permit_features = permit_layer.selectedFeatures()
        fiber_features = fiber_layer.selectedFeatures()

        if len(permit_features) != 1:
            QMessageBox.warning(self, 'Selection Error', 'Select exactly one permit point.')
            return

        if not fiber_features:
            QMessageBox.warning(self, 'Selection Error', 'Select one or more fiber segments.')
            return

        permit_id = str(permit_features[0]['id'])
        segment_ids = [str(f['id']) for f in fiber_features]

        # Extract the 'user' from the layer's data source URI
        uri = permit_layer.dataProvider().dataSourceUri()
        user_value = None

        # Handle both quoted and unquoted values for user=
        print(f"PERMITS URI: {uri}")
        for part in uri.split(' '):
            if part.startswith("user="):
                user_value = part.split("=", 1)[1].strip("'")
                break

        if not user_value:
            QMessageBox.warning(self, 'Error', 'Could not determine the connected user from the permits layer.')
            return

        try:
            conn = psycopg2.connect(**DB_CONFIG)
            cur = conn.cursor()

            for seg_id in segment_ids:
                # First, remove any existing association
                cur.execute("""
                    DELETE FROM public.permit_fiber_association
                    WHERE permit_id = %s AND segment_id = %s;
                """, (permit_id, seg_id))

                # Then, insert the new one with updated metadata
                cur.execute("""
                    INSERT INTO public.permit_fiber_association (permit_id, segment_id, created_by)
                    VALUES (%s, %s, %s);
                """, (permit_id, seg_id, user_value))

            conn.commit()
            cur.close()
            conn.close()

            QMessageBox.information(self, 'Success', f'Associated {len(segment_ids)} segments with permit {permit_id}.')

        except Exception as e:
            QMessageBox.critical(self, 'Database Error', str(e))
