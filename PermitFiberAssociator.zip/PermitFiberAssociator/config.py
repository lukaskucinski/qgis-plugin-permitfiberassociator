# config.py

DB_CONFIG = {
    "host": "osit.clykogc46001.us-west-2.rds.amazonaws.com",
    "dbname": "osit",
    "user": "read_only_user",
    "password": "osit123",
    "port": "5432"
}
